<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Basic -->
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <!-- Mobile Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <!-- Site Metas -->
    <meta name="keywords" content="" />
    <meta name="description" content="" />
    <meta name="author" content="" />

    <title>Help and Support Sénégal</title>

    <!-- slider stylesheet -->
    <link rel="stylesheet" type="text/css"
        href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.1.3/assets/owl.carousel.min.css" />

    <!-- bootstrap core css -->
    <link rel="stylesheet" type="text/css" href="../css/bootstrap.css" />

    <!-- fonts style -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,700|Poppins:400,700|Roboto:400,700&display=swap"
        rel="stylesheet" />

    <!-- Custom styles for this template -->
    <link href="../css/style.css" rel="stylesheet" />
    <!-- responsive style -->
    <link href="../css/responsive.css" rel="stylesheet" />
</head>

<body>
    <div class="hero_area">



        <!-- custom menu -->
        <div class="custom_menu-container">
            <div class="container">
                <div class="custom_menu">
                    <ul class="navbar-nav ">
                        <li class="nav-item active">
                            <a class="nav-link pl-0" href="index.html">Accueil <span
                                    class="sr-only">(current)</span></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="about.html">A propos </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="portfolio.html">Nos activités </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="service.html">Nos projets</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="contact.html">Contactez-nous</a>
                        </li>
                    </ul>
                    <div class="user_option">
                        <div class="login_btn-container">
                            <a href="">
                                Connexion
                            </a>
                        </div>
                        <form class="form-inline my-2 my-lg-0">
                            <button class="btn  my-2 my-sm-0 nav_search-btn" type="submit"></button>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <!-- custom menu -->






        <!-- header section strats -->
        <header class="header_section">
            <div class="container-fluid">
                <nav class="navbar navbar-expand-lg custom_nav-container pt-3">
                    <a class="navbar-brand" href="index.html">
                        <img src="../images/WhatsApp Image 2023-04-10 at 15.59.27.jpeg" alt="" />
                        <span>
                            Help and Support Sénégal
                        </span>
                    </a>
                    <button class="navbar-toggler" type="button" data-toggle="collapse"
                        data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                        aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>

                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul class="navbar-nav ml-auto mr-2">
                            <li class="nav-item active">
                                <a class="nav-link" href="index.html">Accueil <span class="sr-only">(current)</span></a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="about.html">A propos </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="portfolio.html">Nos activités</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="service.html">Nos projets</a>
                            </li>

                            <li class="nav-item">
                                <a class="nav-link" href="contact.html">Contactez-nous</a>
                            </li>
                        </ul>
                        <div class="user_option">
                            <div class="login_btn-container">
                                <a href="">
                                    Connexion
                                </a>
                            </div>
                            <form class="form-inline my-2 my-lg-0">
                                <button class="btn  my-2 my-sm-0 nav_search-btn" type="submit"></button>
                            </form>
                        </div>
                    </div>
                    <div class="call_btn">
                        <a href="">
                            Téléphone : +221 77 786 67 54
                        </a>
                    </div>
                </nav>
            </div>
        </header>






        <!-- end header section -->

        <section class="slider_section">
            <div class="container-fluid">
                <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
                    <div class="carousel-inner">
                        <div class="carousel-item active">
                            <div class="row">
                                <div class="col-md-3 col-lg-2 offset-md-2">
                                    <div class="detail-box">
                                        <h1>
                                            Aide mutuelle
                                        </h1>
                                        <p>
                                            Nous sommes tous embarqués sur le même navire, et pour sauver le navire,
                                            nous devons nous aider mutuellement
                                        </p>
                                        <div>
                                            <a href="">
                                                Savoir plus
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-7 col-lg-8">
                                    <div class="img-box">
                                        <img src="../images/mai.png" alt="" />
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="carousel-item">
                            <div class="row">
                                <div class="col-md-3 col-lg-2 offset-md-2">
                                    <div class="detail-box">
                                        <h1>
                                            Entraide collective
                                        </h1>
                                        <p>
                                            La force d'une communauté réside dans la volonté et la capacité de ses
                                            membres à s'entraider
                                        </p>
                                        <div>
                                            <a href="">
                                                Savoir plus
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-7 col-lg-8">
                                    <div class="img-box">
                                        <img src="../images/mamech.jpg" alt="" />
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="carousel-item">
                            <div class="row">
                                <div class="col-md-3 col-lg-2 offset-md-2">
                                    <div class="detail-box">
                                        <h1>
                                            Responsabilité partagée
                                        </h1>
                                        <p>
                                            La responsabilité partagée est la seule voie pour construire un monde où
                                            chaque individu a la possibilité de réaliser son plein potentiel
                                        </p>
                                        <div>
                                            <a href="">
                                                Savoir plus
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-7 col-lg-8">
                                    <div class="img-box">
                                        <img src="../images/maii.png" alt="" />
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
                        <span class="sr-only">
                            Précédent
                        </span>
                    </a>
                    <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
                        <span class="sr-only">Suivant</span>
                    </a>
                </div>
            </div>
        </section>
    </div>



    <!-- about section -->

    <section class="about_section layout_padding mt-5">
        <div class="container">
            <div class="row">
                <div class="col-md-7">
                    <div class="img-box">
                        <img src="../images/about-img.png" alt="" />
                    </div>
                </div>
                <div class="col-md-5">
                    <div class="detail-box">
                        <div class="custom_heading-container">
                            <h2>
                                A propos de HSS
                            </h2>
                        </div>

                        <p>
                            Help and Support Sénégal (HSS) est une organisation à but non lucratif qui s'engage à aider
                            les communautés les plus vulnérables au Sénégal. Le groupe se compose de membres dévoués et
                            passionnés qui travaillent ensemble pour fournir des solutions pratiques aux défis sociaux
                            et économiques auxquels sont confrontées les populations locales.
                        </p>
                        <div>
                            <a href="">
                                À propos Plus
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- end about section -->

    <!-- do section -->
    <section class="do_section layout_padding-bottom">
        <div class="container">
            <div class="custom_heading-container">
                <h2>
                    Ce que nous faisons
                </h2>
            </div>
            <div class="row">
                <div class="col-md-3 col-sm-6">
                    <div class="content-box bg-red">
                        <div class="img-box">
                            <img src="../images/idea.png" alt="" />
                        </div>
                        <div class="detail-box">
                            <h6>
                                Sensibilisation et prévention
                            </h6>
                            <p>
                                Sensibilisation, prévention et éducation aux enjeux sociaux
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6">
                    <div class="content-box bg-green">
                        <div class="img-box">
                            <img src="../images/controller.png" alt="" />
                        </div>
                        <div class="detail-box">
                            <h6>
                                Aide et soutien aux personnes en difficulté
                            </h6>
                            <p>
                                Aide et accompagnement aux personnes précaires.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6">
                    <div class="content-box bg-red">
                        <div class="img-box">
                            <img src="../images/monitor.png" alt="" />
                        </div>
                        <div class="detail-box">
                            <h6>
                                Développement de projets et d'activités
                            </h6>
                            <p>
                                Projets et activités pour améliorer la vie communautaire.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6">
                    <div class="content-box bg-green">
                        <div class="img-box">
                            <img src="../images/rocket-ship.png" alt="" />
                        </div>
                        <div class="detail-box">
                            <h6>
                                Recherche et développement
                            </h6>
                            <p>
                                Recherche, développement et innovation de programmes pour populations vulnérables.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- end do section -->
    <!-- skill section -->

    <section class="skill_section layout_padding2">
        <div class="container">
            <div class="custom_heading-container">
                <h2>

                    Nos domaines
                </h2>
            </div>
            <div class="skill_padding">
                <div class="row">
                    <div class="col-md-3 col-sm-6">
                        <div class="box">
                            <div class="circle" id="circles-1"></div>
                            <h6>
                                Santé
                            </h6>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6">
                        <div class="box">
                            <div class="circle" id="circles-2"></div>
                            <h6>
                                Education
                            </h6>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6">
                        <div class="box">
                            <div class="circle" id="circles-3"></div>
                            <h6>
                                Environement
                            </h6>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6">
                        <div class="box">
                            <div class="circle" id="circles-4"></div>
                            <h6>
                                Jeunesse
                            </h6>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- end skill section -->

    <!-- portfolio section -->
    <section class="portfolio_section layout_padding">
        <div class="container">
            <div class="custom_heading-container">
                <h2>
                    Notre Portfolio
                </h2>
            </div>
        </div>
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-6">
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="box b-1">
                                <img src="../images/WhatsApp Image 2023-04-10 at 12.15.58.jpeg" alt="" />
                                <h4>
                                    Aider
                                </h4>
                            </div>
                            <div class="box b-2">
                                <img src="../images/WhatsApp Image 2023-04-10 at 12.46.27.jpeg" alt="" />
                                <h4>
                                    Colaborer
                                </h4>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="box b-3">
                                <img src="../images/WhatsApp Image 2023-04-10 at 16.41.35.jpeg" alt="" />
                                <h4>
                                    se divertir
                                </h4>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="box b-4">
                                <img src="../images/WhatsApp Image 2023-04-10 at 17.38.36.jpeg" alt="" />
                                <h4>
                                    Promouvoir
                                </h4>
                            </div>
                            <div class="box b-5">
                                <img src="../images/WhatsApp Image 2023-04-10 at 17.38.56.jpeg" alt="" />
                                <h4>
                                    Servir
                                </h4>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="box b-6">
                                <img src="../images/WhatsApp Image 2023-04-10 at 12.46.49.jpeg" alt="" />
                                <h4>
                                    Percer
                                </h4>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- end portfolio section -->

    <!-- client section -->


    <!-- end client section -->

    <!-- contact section -->

    <section class="contact_section ">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-4 offset-lg-2 col-md-5 offset-md-1">
                    <h2 class="custom_heading">Contactez-nous</h2>
                    <form action="#">
                        <div>
                            <input type="text" placeholder="Nom" />
                        </div>
                        <div>
                            <input type="email" placeholder="Email" />
                        </div>
                        <div>
                            <input type="text" placeholder="Téléphone" />
                        </div>
                        <div>
                            <input type="text" class="message-box" placeholder="Message" />
                        </div>
                        <div class="d-flex  mt-4 ">
                            <button>
                                ENVOYER
                            </button>
                        </div>
                    </form>
                </div>
                <div class="col-md-6 px-0">
                    <div class="img-box">
                        <img src="../images/contact.jpg" alt="" class="w-100" />
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- end contact section -->

    <!-- info section -->
    <section class="info_section layout_padding-top layout_padding2-bottom">
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-lg-3">
                    <div class="info_links pl-lg-5">
                        <h4>
                            Menu
                        </h4>
                        <ul>
                            <li class="active">
                                <a href="index.html">
                                    Accueil
                                </a>
                            </li>
                            <li>
                                <a href="about.html">
                                    A propos
                                </a>
                            </li>
                            <li>
                                <a class="" href="portfolio.html">Nos activités </a>
                            </li>
                            <li>
                                <a class="" href="service.html">Nos projets</a>
                            </li>
                            <li>
                                <a href="contact.html">
                                    Contactez - Nous
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="col-md-6 col-lg-3">
                    <div class="info_contact">
                        <h4>
                            Emplacement
                        </h4>
                        <div>
                            <img src="images/location.png" alt="" />
                            <p>
                                Sénégal,
                            </p>
                        </div>
                        <div>
                            <img src="images/telephone.png" alt="" />
                            <p>
                                +221 77 786 67 54
                            </p>
                        </div>
                        <div>
                            <img src="images/envelope.png" alt="" />
                            <p>
                                hss221@gmail.com
                            </p>
                        </div>
                    </div>
                </div>

                <div class="col-md-6 col-lg-3">
                    <div class="info_social">
                        <h4>
                            Réseaux sociaux
                        </h4>
                        <div class="social_container">
                            <div>
                                <a href="">
                                    <img src="images/facebook-logo.png" alt="" />
                                </a>
                            </div>
                            <div>
                                <a href="">
                                    <img src="images/twitter-logo.png" alt="" />
                                </a>
                            </div>
                            <div>
                                <a href="">
                                    <img src="images/instagram.png" alt="" />
                                </a>
                            </div>
                            <div>
                                <a href="">
                                    <img src="images/linkedin-sign.png" alt="" />
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-3">
                    <div class="info_form">
                        <h4>
                            Newsletter
                        </h4>
                        <form action="#">
                            <input type="text" placeholder="
              Entrer votre Email" />
                            <button type="submit">
                                S'abonner
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- end info_section -->

    <!-- footer section -->
    <footer class="container-fluid footer_section">
        <p>
            &copy; 2023 Tous droits réservés par
            <a href="https://html.design/">Help and Support Sénégal</a>
        </p>
    </footer>
    <!-- footer section -->

    <script src="js/jquery-3.4.1.min.js"></script>
    <script src="js/bootstrap.js"></script>
    <script src="js/circles.min.js"></script>
    <script src="js/custom.js"></script>


</body>

</html>